import { Button } from "@/components/ui/button";

interface CategoryFilterProps {
  categories: string[];
  activeCategory: string;
  onCategoryChange: (category: string) => void;
  promptCounts: Record<string, number>;
}

export const CategoryFilter = ({ 
  categories, 
  activeCategory, 
  onCategoryChange, 
  promptCounts 
}: CategoryFilterProps) => {
  
  const getCategoryVariant = (category: string) => {
    if (activeCategory === category) {
      switch (category.toLowerCase()) {
        case 'all prompts': return 'default';
        case 'men': return 'primary';
        case 'women': return 'secondary';
        case 'couple': return 'accent';
        case 'kids': return 'warning';
        default: return 'default';
      }
    }
    return 'ghost';
  };

  const getCategoryGradient = (category: string) => {
    if (activeCategory !== category) return '';
    
    switch (category.toLowerCase()) {
      case 'all prompts': return 'glow-pulse';
      case 'men': return 'bg-gradient-primary glow-pulse';
      case 'women': return 'bg-gradient-secondary glow-pulse';
      case 'couple': return 'bg-gradient-accent glow-pulse';
      case 'kids': return 'bg-warning glow-pulse';
      default: return 'glow-pulse';
    }
  };

  return (
    <div className="flex flex-wrap gap-3 justify-center mb-8">
      {categories.map((category) => (
        <Button
          key={category}
          variant={getCategoryVariant(category)}
          onClick={() => onCategoryChange(category)}
          className={`
            px-6 py-2 rounded-full transition-all duration-300 capitalize
            hover:scale-105 hover:shadow-elevated
            ${getCategoryGradient(category)}
            ${activeCategory === category ? 'text-white font-semibold' : 'text-muted-foreground hover:text-foreground'}
          `}
        >
          {category}
          <span className="ml-2 px-2 py-0.5 bg-black/20 rounded-full text-xs">
            {promptCounts[category] || 0}
          </span>
        </Button>
      ))}
    </div>
  );
};