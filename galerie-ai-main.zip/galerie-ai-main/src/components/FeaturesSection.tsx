import { Copy, Filter, Zap, Shield, Smartphone, Globe } from "lucide-react";

export const FeaturesSection = () => {
  const features = [
    {
      icon: <Copy className="h-6 w-6" />,
      title: "One-Click Copy",
      description: "Instantly copy any AI prompt to your clipboard with a single click"
    },
    {
      icon: <Filter className="h-6 w-6" />,
      title: "Smart Filtering",
      description: "Browse prompts by categories: Men, Women, Couple, Kids"
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Real-time Updates",
      description: "Gallery updates instantly when new prompts are added"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Admin Panel",
      description: "Secure admin interface for managing prompts and content"
    },
    {
      icon: <Smartphone className="h-6 w-6" />,
      title: "Mobile Responsive",
      description: "Perfect viewing experience on all devices and screen sizes"
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: "VPS Ready",
      description: "Optimized for deployment on virtual private servers"
    }
  ];

  return (
    <div className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Powerful Features
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Everything you need to manage and browse AI prompts efficiently
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
            >
              <div className="text-blue-600 mb-4">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 max-w-2xl mx-auto">
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Need Backend Functionality?
            </h3>
            <p className="text-gray-600 mb-4">
              For real-time database updates, file storage, and persistent data, connect your project to Supabase for full backend capabilities.
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-blue-600">
              <Shield className="h-4 w-4" />
              <span>Secure • Scalable • Real-time</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};