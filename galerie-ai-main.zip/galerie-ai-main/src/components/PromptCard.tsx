import { useState } from "react";
import { Copy, Check, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface PromptCardProps {
  image: string;
  prompt: string;
  category: string;
  className?: string;
  style?: React.CSSProperties;
}

export const PromptCard = ({ image, prompt, category, className = "", style }: PromptCardProps) => {
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false);
  const { toast } = useToast();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(prompt);
      setCopied(true);
      toast({
        title: "Copied to clipboard!",
        description: "The prompt has been copied to your clipboard.",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  const getCategoryColor = (cat: string) => {
    switch (cat.toLowerCase()) {
      case 'men': return 'bg-gradient-primary';
      case 'women': return 'bg-gradient-secondary';
      case 'couple': return 'bg-gradient-accent';
      case 'kids': return 'bg-warning';
      default: return 'bg-muted';
    }
  };

  return (
    <div 
      className={`group relative bg-card rounded-xl overflow-hidden glow-card animate-fade-in ${className}`}
      style={style}
    >
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden">
        <img 
          src={image} 
          alt={`${category} prompt`}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Action Buttons */}
        <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button
            size="sm"
            variant="ghost"
            className="glass-card text-white hover:bg-white/20 h-8 w-8 p-0"
            onClick={() => setLiked(!liked)}
          >
            <Heart className={`h-4 w-4 ${liked ? 'fill-red-500 text-red-500' : ''}`} />
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            className="glass-card text-white hover:bg-white/20 h-8 w-8 p-0"
            onClick={handleCopy}
          >
            {copied ? (
              <Check className="h-4 w-4 text-success" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Category Badge */}
        <div className="absolute top-3 left-3">
          <Badge className={`${getCategoryColor(category)} text-white border-0 font-medium capitalize`}>
            {category}
          </Badge>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
          {prompt}
        </p>
        
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleCopy}
          className="w-full bg-surface/50 border-border-accent hover:bg-gradient-primary hover:text-primary-foreground hover:border-primary transition-all duration-300"
        >
          {copied ? (
            <>
              <Check className="h-4 w-4 mr-2" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="h-4 w-4 mr-2" />
              Copy Prompt
            </>
          )}
        </Button>
      </div>
    </div>
  );
};