import { useState, useEffect } from "react";
import { X, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export const TelegramNotification = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isEnabled, setIsEnabled] = useState(true);

  useEffect(() => {
    // Show notification after 3 seconds if enabled
    if (isEnabled) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [isEnabled]);

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleToggle = () => {
    setIsEnabled(!isEnabled);
    if (isEnabled) {
      setIsVisible(false);
    }
  };

  if (!isVisible || !isEnabled) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={handleToggle}
          variant="outline"
          size="sm"
          className="bg-white border-gray-300 text-gray-600 hover:bg-gray-50"
        >
          <MessageCircle className="h-4 w-4 mr-1" />
          {isEnabled ? 'Hide' : 'Show'} Notifications
        </Button>
      </div>
    );
  }

  return (
    <>
      {/* Toggle Button */}
      <div className="fixed bottom-20 right-4 z-50">
        <Button
          onClick={handleToggle}
          variant="outline"
          size="sm"
          className="bg-white border-gray-300 text-gray-600 hover:bg-gray-50"
        >
          <MessageCircle className="h-4 w-4 mr-1" />
          Hide Notifications
        </Button>
      </div>

      {/* Notification */}
      <div className="fixed bottom-4 right-4 z-50 animate-slide-in-right">
        <div className="bg-white border border-gray-200 rounded-lg shadow-lg p-4 max-w-sm">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-blue-100 rounded-full">
                <MessageCircle className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 text-sm">
                  Join our Telegram Channel
                </h3>
                <p className="text-gray-600 text-xs mt-1">
                  Get latest AI prompts and updates directly in Telegram
                </p>
                <a
                  href="https://t.me/your_channel"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block mt-2 px-3 py-1 bg-blue-600 text-white text-xs rounded-full hover:bg-blue-700 transition-colors"
                >
                  Join Now
                </a>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="text-gray-400 hover:text-gray-600 h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};