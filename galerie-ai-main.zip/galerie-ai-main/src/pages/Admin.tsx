import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Upload, Plus, X, ArrowLeft, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "react-router-dom";

interface Prompt {
  id: string;
  image: string;
  prompt: string;
  category: string;
}

export const Admin = () => {
  const [formData, setFormData] = useState({
    image: '',
    prompt: '',
    category: ''
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  // Mock data for existing prompts - in real app this would come from database
  const [prompts, setPrompts] = useState<Prompt[]>([
    {
      id: "1",
      image: "/api/placeholder/400/300",
      prompt: "Professional portrait of a confident business man in modern office setting",
      category: "Men"
    },
    {
      id: "2", 
      image: "/api/placeholder/400/300",
      prompt: "Elegant professional woman in modern workspace",
      category: "Women"
    }
  ]);

  const categories = ['Men', 'Women', 'Couple', 'Kids'];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setImagePreview(result);
        setFormData(prev => ({ ...prev, image: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.image || !formData.prompt || !formData.category) {
      toast({
        title: "Missing fields",
        description: "Please fill in all fields before submitting.",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    
    try {
      // Simulate upload process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const newPrompt: Prompt = {
        id: Date.now().toString(),
        image: formData.image,
        prompt: formData.prompt,
        category: formData.category
      };

      setPrompts(prev => [newPrompt, ...prev]);

      toast({
        title: "Success!",
        description: "Prompt added successfully!",
      });

      // Reset form
      setFormData({ image: '', prompt: '', category: '' });
      setImageFile(null);
      setImagePreview('');
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = (id: string) => {
    setPrompts(prev => prev.filter(p => p.id !== id));
    toast({
      title: "Deleted",
      description: "Prompt removed successfully!",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Gallery
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
                <p className="text-gray-600">Manage AI prompts and gallery content</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Add New Prompt */}
          <Card className="p-6 bg-white border border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Add New Prompt</h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Image Upload */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">Image Upload</label>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="bg-white border-gray-300"
                    />
                  </div>
                  {imagePreview && (
                    <div className="w-16 h-16 rounded-lg overflow-hidden border border-gray-300">
                      <img 
                        src={imagePreview} 
                        alt="Preview" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Category Selection */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">Category</label>
                <Select value={formData.category} onValueChange={(value) => 
                  setFormData(prev => ({ ...prev, category: value }))
                }>
                  <SelectTrigger className="bg-white border-gray-300">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-300">
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Prompt Text */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">AI Prompt</label>
                <Textarea
                  value={formData.prompt}
                  onChange={(e) => setFormData(prev => ({ ...prev, prompt: e.target.value }))}
                  placeholder="Enter the detailed AI prompt for this image..."
                  rows={6}
                  className="bg-white border-gray-300 resize-none"
                />
                <p className="text-xs text-gray-500">
                  Write a detailed prompt that would generate this type of image
                </p>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={uploading}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                {uploading ? (
                  <>
                    <Upload className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Prompt
                  </>
                )}
              </Button>
            </form>
          </Card>

          {/* Existing Prompts */}
          <Card className="p-6 bg-white border border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Existing Prompts ({prompts.length})</h2>
            
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {prompts.map((prompt) => (
                <div key={prompt.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <img 
                      src={prompt.image} 
                      alt="Prompt" 
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <span className="inline-block px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                          {prompt.category}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(prompt.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {prompt.prompt}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
