import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { PromptCard } from "@/components/PromptCard";
import { CategoryFilter } from "@/components/CategoryFilter";
import { TelegramNotification } from "@/components/TelegramNotification";
import { FeaturesSection } from "@/components/FeaturesSection";
import { Settings, Sparkles, Zap } from "lucide-react";
import { Link } from "react-router-dom";

// Import sample images
import sampleMen1 from "@/assets/sample-men-1.jpg";
import sampleWomen1 from "@/assets/sample-women-1.jpg";
import sampleCouple1 from "@/assets/sample-couple-1.jpg";
import sampleKids1 from "@/assets/sample-kids-1.jpg";

interface Prompt {
  id: string;
  image: string;
  prompt: string;
  category: string;
}

export const Gallery = () => {
  const [activeCategory, setActiveCategory] = useState("All Prompts");
  
  const [prompts, setPrompts] = useState<Prompt[]>([
    {
      id: "1",
      image: sampleMen1,
      prompt: "Professional portrait of a confident business man in modern office setting, wearing a stylish navy suit, crisp lighting, contemporary aesthetic, realistic photography, high resolution, professional headshot style",
      category: "Men"
    },
    {
      id: "2",
      image: sampleWomen1,
      prompt: "Elegant professional woman in modern workspace, wearing sophisticated attire, natural lighting, contemporary style, realistic photography, high resolution, professional portrait style",
      category: "Women"
    },
    {
      id: "3",
      image: sampleCouple1,
      prompt: "Happy couple walking together in modern urban setting, stylish casual attire, warm natural lighting, contemporary lifestyle, realistic photography, high resolution, romantic couple portrait",
      category: "Couple"
    },
    {
      id: "4",
      image: sampleKids1,
      prompt: "Cheerful children playing in modern playground, bright colorful clothing, natural outdoor lighting, joyful family atmosphere, realistic photography, high resolution, family portrait style",
      category: "Kids"
    }
  ]);

  const categories = ["All Prompts", "Men", "Women", "Couple", "Kids"];

  const filteredPrompts = useMemo(() => {
    if (activeCategory === "All Prompts") {
      return prompts;
    }
    return prompts.filter(prompt => prompt.category === activeCategory);
  }, [prompts, activeCategory]);

  const promptCounts = useMemo(() => {
    const counts: Record<string, number> = {
      "All Prompts": prompts.length
    };
    
    categories.slice(1).forEach(category => {
      counts[category] = prompts.filter(p => p.category === category).length;
    });
    
    return counts;
  }, [prompts, categories]);


  return (
    <div className="min-h-screen bg-white">
      {/* Hero Header */}
      <div className="relative bg-white border-b border-gray-200 shadow-sm">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-50 via-transparent to-purple-50" />
        <div className="relative container mx-auto px-4 py-12">
          <div className="text-center space-y-6">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="p-3 bg-gradient-primary rounded-2xl shadow-primary">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-4xl md:text-6xl font-bold">
                <span className="bg-gradient-primary bg-clip-text text-transparent">
                  AI Prompt
                </span>
                <span className="text-gray-900"> Gallery</span>
              </h1>
            </div>
            
            <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
              Discover and copy amazing AI prompts for generating stunning images. 
              Browse by category and find inspiration for your next creation.
            </p>

            <div className="flex items-center justify-center gap-6 text-gray-600">
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-blue-600" />
                <span className="font-semibold text-gray-900">{prompts.length}</span>
                <span>Prompts Available</span>
              </div>
              <div className="w-1 h-1 bg-gray-300 rounded-full" />
              <div className="flex items-center gap-2">
                <span>Real-time Updates</span>
              </div>
            </div>

            {/* Admin Access */}
            <div className="pt-4">
              <Link to="/admin">
                <Button
                  variant="outline"
                  className="bg-white/50 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300 border-gray-300"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Admin Panel
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        {/* Category Filter */}
        <CategoryFilter
          categories={categories}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
          promptCounts={promptCounts}
        />

        {/* Results Count */}
        <div className="text-center mb-8">
          <p className="text-gray-600">
            Showing <span className="font-semibold text-gray-900">{filteredPrompts.length}</span> prompts
            {activeCategory !== "All Prompts" && (
              <span> in <span className="font-semibold text-blue-600">{activeCategory}</span></span>
            )}
          </p>
        </div>

        {/* Prompt Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredPrompts.map((prompt, index) => (
            <PromptCard
              key={prompt.id}
              image={prompt.image}
              prompt={prompt.prompt}
              category={prompt.category}
              className={`animate-fade-in`}
              style={{ animationDelay: `${index * 0.1}s` } as React.CSSProperties}
            />
          ))}
        </div>

        {/* Empty State */}
        {filteredPrompts.length === 0 && (
          <div className="text-center py-12">
            <div className="space-y-4">
              <div className="p-4 bg-gray-100 rounded-2xl w-fit mx-auto">
                <Sparkles className="h-12 w-12 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-700">
                No prompts found in this category
              </h3>
              <p className="text-gray-500">
                Try selecting a different category or add new prompts
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Features Section */}
      <FeaturesSection />

      {/* Telegram Notification */}
      <TelegramNotification />
    </div>
  );
};