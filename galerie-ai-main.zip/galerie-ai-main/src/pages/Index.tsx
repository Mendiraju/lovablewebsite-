import { Gallery } from "./Gallery";

const Index = () => {
  return <Gallery />;
};

export default Index;
